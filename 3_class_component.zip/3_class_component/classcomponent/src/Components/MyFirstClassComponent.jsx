import React from 'react';

class Team extends React.Component {
  render() {
    return <h1>Class Component</h1>
  }
}

export default Team;