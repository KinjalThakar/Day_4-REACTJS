import logo from './logo.svg';
import './App.css';
import Myfunctioncomponent from './components/myfunctioncomponent';
import Myclasscomponent from './components/myclasscomponent';

function App() {
    return ( <>
            <h1>App Component</h1>
            <Myfunctioncomponent / >
            <Myclasscomponent / >
            </>
    );
}

export default App;