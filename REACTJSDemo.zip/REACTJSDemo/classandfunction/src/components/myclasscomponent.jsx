import React from 'react'
class myclasscomponent extends React.Component {
    render() {
        return <h2 > Custom Class Component. < /h2>
    }
}

export default myclasscomponent;