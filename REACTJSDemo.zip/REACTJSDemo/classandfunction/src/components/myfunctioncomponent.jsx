function myfunctioncomponent() {
    return ( < h2 > My Function Components < /h2>);
    }

    export default myfunctioncomponent;