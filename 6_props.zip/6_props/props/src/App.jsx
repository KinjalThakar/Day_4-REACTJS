import './App.css';
import PersonDefaultDemo from './Components/DefaultProp'
//import ArrayProps from './Components/ArrayAsProps'
//import ParentSampleRenderProps from './Components/RenderPropDemo'
//import GrandParent from './Components/Live';

function App() {
  return (
    //  Array as Props;
    //  <ArrayProps></ArrayProps>
    
    // Default Prop - Class Componet with Props;
    <div>
      <PersonDefaultDemo></PersonDefaultDemo>
      <PersonDefaultDemo name="Kshitij Vyas" gender="Male"></PersonDefaultDemo>
      <PersonDefaultDemo name="Kinjal Vyas" gender="Female"></PersonDefaultDemo>
      <PersonDefaultDemo name="Dhruv Thakar" gender="Male"></PersonDefaultDemo>
    </div>

  //   Render Props;
  //  <ParentSampleRenderProps/>
    
  );
}
export default App;
