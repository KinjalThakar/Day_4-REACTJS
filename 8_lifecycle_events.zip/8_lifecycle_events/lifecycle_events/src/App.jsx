import './App.css';
import LifeCycle from './Components/LifeCycle'
function App() {
  return (
    <>
    <h1>My Name is Kinjal Thakar.</h1>
    <LifeCycle/>
    </>
  );
}

export default App;
